<h1>My first svelte component</h1>
<p>
	Hello World
</p>
<div>
	<a href="https://www.youtube.com/watch?v=UGBJHYpHPvA">Link to my youtube</a>
</div>
<style>
	h1{
		color: rebeccapurple;
	}
	p{
		font-size:44px;
	}
</style>
<script>
	let name="Bhargavi";
</script>